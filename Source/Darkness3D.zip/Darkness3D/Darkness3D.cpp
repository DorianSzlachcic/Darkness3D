// Copyright Epic Games, Inc. All Rights Reserved.

#include "Darkness3D.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Darkness3D, "Darkness3D" );
